a = int(input("Odmalar sonini kiriting :"))

def man ():
    print(a//5)
man()