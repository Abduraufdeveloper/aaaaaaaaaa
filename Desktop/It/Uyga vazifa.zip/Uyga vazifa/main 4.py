n = 38
def two_digit_sum(n):
    return n % 10 + n // 10

print(two_digit_sum(n))