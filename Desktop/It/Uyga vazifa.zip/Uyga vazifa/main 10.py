list = [5,2,10]
for x in list :
    a = list[0] + list[0]
    b = a + a
    if b % list[2] == 1 :
        print("False")
    elif b % list[2] == 0 :
        print("True")
        break

