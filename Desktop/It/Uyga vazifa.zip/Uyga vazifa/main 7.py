a = int(input("sonni kiriting :"))
def good_math(a):
    for x in a :
        x = type(x) == int()
        if len(a) % 2 == 0 :
            b = a[0] + a[1],a[2] + a [3],a[4] + a[5]
            print(f"{a} is good math ")
        elif len(a) % 2 == 1 :
            print(f"{a} is bad math")
    return (good_math(a))