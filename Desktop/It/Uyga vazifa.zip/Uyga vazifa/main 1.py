a = int(input("Enter 'a'"))
b = int(input("Enter 'b'"))
c = int(input("Enter 'c'"))


def abcmath(a, b, c):
    u = (a * 2 ** b) % c
    if u == 0:
        print(True)
    else:
        print(False)


abcmath(a, b, c)