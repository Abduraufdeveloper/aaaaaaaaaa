a = int(input("Sonni kiriting :"))
b = int(input("sonni kiriting :"))
for x in range(b):
    a += 1
    if a % b == 0:
        print(a)