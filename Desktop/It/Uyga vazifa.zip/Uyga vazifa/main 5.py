height_of_stair = float(input("Enter height of each stair(in cm): "))
len_of_stair = float(input("Enter length of each stair(in cm): "))
tower_height = float(input("Enter height of tower (in metres): "))

def sam(leng, hei, tow):
    height_m = hei / 100
    length_m = leng / 100
    num_of_steps = tow / height_m
    total_distance = num_of_steps * length_m + tow
    rounded_distance = round(total_distance, 1)
    return rounded_distance

result = sam(len_of_stair, height_of_stair, tower_height)

print(f" The total distance snail has gone is {result} metres")