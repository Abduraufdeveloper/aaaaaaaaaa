list = int(input("sonni kiriting :"))
while True :
    for x in list :
        if x % 2 == 0 :
            b = (x // 2)
            while  b == 1 :
                print(b)
            break
        elif x % 2 == 1 :
            b = (x * 3 + 1)
            while b == 1 :
                print(b)
            break

    break