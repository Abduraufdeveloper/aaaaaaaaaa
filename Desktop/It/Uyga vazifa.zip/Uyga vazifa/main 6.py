lists = [3, 6, -2, -5, 7, 3]


def product(list):
    if len(list) < 2:
        return None

    b = float('-inf')

    for i in range(len(list) - 1):
        a = list[i] * list[i + 1]
        if a > b:
            b = a

    return b


print(f" {lists} → {product(lists)}")